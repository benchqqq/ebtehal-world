import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const messages = await db.message.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(messages)

  } catch (error) {
    console.error('Get messages error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value
    const currentUserName = request.cookies.get('currentUserName')?.value

    if (!coupleId || !currentUserName) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { content } = await request.json()

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'محتوى الرسالة مطلوب' },
        { status: 400 }
      )
    }

    const message = await db.message.create({
      data: {
        content: content.trim(),
        sender: currentUserName,
        coupleId
      }
    })

    return NextResponse.json(message)

  } catch (error) {
    console.error('Create message error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}