'use client'

import { useState, useEffect, useRef } from 'react'
import { Music, Play, Pause, Volume2, VolumeX } from 'lucide-react'

const romanticSongs = [
  {
    id: 1,
    title: "لحن الحب",
    artist: "حبيب القلب",
    url: "/music/romantic1.mp3"
  },
  {
    id: 2,
    title: "همسات الروح",
    artist: "عاشق secreto",
    url: "/music/romantic2.mp3"
  },
  {
    id: 3,
    title: "دقات القلب",
    artist: "الحب الحقيقي",
    url: "/music/romantic3.mp3"
  }
]

export function RomanticMusic() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentSongIndex, setCurrentSongIndex] = useState(0)
  const [volume, setVolume] = useState(0.3)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  const currentSong = romanticSongs[currentSongIndex]

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume
    }
  }, [volume, isMuted])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleEnded = () => {
      playNextSong()
    }

    audio.addEventListener('ended', handleEnded)
    return () => audio.removeEventListener('ended', handleEnded)
  }, [currentSongIndex])

  const togglePlayPause = async () => {
    if (!audioRef.current) return

    setIsLoading(true)
    try {
      if (isPlaying) {
        await audioRef.current.pause()
      } else {
        await audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    } catch (error) {
      console.error('Audio playback error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const playNextSong = () => {
    const nextIndex = (currentSongIndex + 1) % romanticSongs.length
    setCurrentSongIndex(nextIndex)
    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.play().catch(console.error)
        setIsPlaying(true)
      }
    }, 100)
  }

  const playPreviousSong = () => {
    const prevIndex = currentSongIndex === 0 ? romanticSongs.length - 1 : currentSongIndex - 1
    setCurrentSongIndex(prevIndex)
    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.play().catch(console.error)
        setIsPlaying(true)
      }
    }, 100)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  return (
    <>
      <audio
        ref={audioRef}
        src={currentSong.url}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />
      
      <div className="fixed bottom-4 right-4 z-50">
        <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-2xl p-4 border border-pink-100 min-w-[300px]">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <Music className="w-5 h-5 text-pink-500 ml-2" />
              <span className="text-sm font-semibold text-gray-700">موسيقى رومانسية</span>
            </div>
            <button
              onClick={toggleMute}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Song Info */}
          <div className="mb-3">
            <div className="text-sm font-semibold text-gray-800 truncate">
              {currentSong.title}
            </div>
            <div className="text-xs text-gray-500 truncate">
              {currentSong.artist}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-3">
            <div className="w-full bg-gray-200 rounded-full h-1">
              <div className="bg-gradient-to-r from-pink-500 to-red-500 h-1 rounded-full w-1/3 animate-pulse" />
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between">
            <button
              onClick={playPreviousSong}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M8.445 14.832A1 1 0 0010 14v-8a1 1 0 00-1.555-.832L3 9.168V6a1 1 0 00-2 0v8a1 1 0 002 0v-3.168l5.445 4z"/>
              </svg>
            </button>

            <button
              onClick={togglePlayPause}
              disabled={isLoading}
              className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-3 rounded-full hover:from-pink-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : isPlaying ? (
                <Pause className="w-5 h-5" />
              ) : (
                <Play className="w-5 h-5" />
              )}
            </button>

            <button
              onClick={playNextSong}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 10.832V14a1 1 0 002 0V6a1 1 0 00-2 0v3.168L4.555 5.168z"/>
              </svg>
            </button>
          </div>

          {/* Volume Control */}
          {!isMuted && (
            <div className="mt-3">
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-pink-500"
              />
            </div>
          )}

          {/* Playlist */}
          <div className="mt-3 pt-3 border-t border-gray-200">
            <div className="text-xs text-gray-500 mb-2">قائمة التشغيل:</div>
            <div className="space-y-1">
              {romanticSongs.map((song, index) => (
                <button
                  key={song.id}
                  onClick={() => {
                    setCurrentSongIndex(index)
                    setTimeout(() => {
                      if (audioRef.current) {
                        audioRef.current.play().catch(console.error)
                        setIsPlaying(true)
                      }
                    }, 100)
                  }}
                  className={`w-full text-right text-xs p-1 rounded transition-colors ${
                    index === currentSongIndex
                      ? 'bg-pink-100 text-pink-700 font-semibold'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {song.title}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}