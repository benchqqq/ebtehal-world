import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const wishes = await db.wish.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(wishes)

  } catch (error) {
    console.error('Get wishes error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { content } = await request.json()

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'محتوى الأمنية مطلوب' },
        { status: 400 }
      )
    }

    const wish = await db.wish.create({
      data: {
        content: content.trim(),
        coupleId
      }
    })

    return NextResponse.json(wish)

  } catch (error) {
    console.error('Create wish error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { wishId, fulfilled } = await request.json()

    if (!wishId) {
      return NextResponse.json(
        { error: 'معرف الأمنية مطلوب' },
        { status: 400 }
      )
    }

    const wish = await db.wish.update({
      where: { 
        id: wishId,
        coupleId 
      },
      data: { fulfilled }
    })

    return NextResponse.json(wish)

  } catch (error) {
    console.error('Update wish error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}