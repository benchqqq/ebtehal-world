import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const memories = await db.memory.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(memories)

  } catch (error) {
    console.error('Get memories error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { title, content, imageUrl } = await request.json()

    if (!title || title.trim().length === 0) {
      return NextResponse.json(
        { error: 'عنوان الذكرى مطلوب' },
        { status: 400 }
      )
    }

    const memory = await db.memory.create({
      data: {
        title: title.trim(),
        content: content?.trim() || null,
        imageUrl: imageUrl?.trim() || null,
        coupleId
      }
    })

    return NextResponse.json(memory)

  } catch (error) {
    console.error('Create memory error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}