'use client'

import { useState, useEffect } from 'react'
import { Heart, Camera, Plus, Calendar, Image as ImageIcon, X } from 'lucide-react'

interface Memory {
  id: string
  title: string
  content?: string
  imageUrl?: string
  createdAt: string
}

export function MemoriesComponent() {
  const [memories, setMemories] = useState<Memory[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newMemory, setNewMemory] = useState({
    title: '',
    content: '',
    imageUrl: ''
  })
  const [adding, setAdding] = useState(false)

  useEffect(() => {
    fetchMemories()
  }, [])

  const fetchMemories = async () => {
    try {
      const response = await fetch('/api/memories')
      if (response.ok) {
        const data = await response.json()
        setMemories(data)
      }
    } catch (error) {
      console.error('Failed to fetch memories:', error)
    } finally {
      setLoading(false)
    }
  }

  const addMemory = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMemory.title.trim()) return

    setAdding(true)
    try {
      const response = await fetch('/api/memories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newMemory),
      })

      if (response.ok) {
        const memory = await response.json()
        setMemories(prev => [memory, ...prev])
        setNewMemory({ title: '', content: '', imageUrl: '' })
        setShowAddForm(false)
      } else {
        const error = await response.json()
        alert(error.error || 'فشل إضافة الذكرى')
      }
    } catch (error) {
      console.error('Failed to add memory:', error)
      alert('حدث خطأ ما')
    } finally {
      setAdding(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  if (loading) {
    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="text-center">
          <Camera className="w-12 h-12 text-blue-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري تحميل الذكريات...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Camera className="w-8 h-8 text-blue-500 ml-3" />
          <h2 className="text-2xl font-bold text-gray-800">ذكرياتنا</h2>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-xl transition-colors shadow-lg"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Add Memory Form */}
      {showAddForm && (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 mb-6 border border-blue-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">إضافة ذكرى جديدة</h3>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <form onSubmit={addMemory} className="space-y-4">
            <input
              type="text"
              placeholder="عنوان الذكرى..."
              value={newMemory.title}
              onChange={(e) => setNewMemory(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
              disabled={adding}
            />
            
            <textarea
              placeholder="صف الذكرى الجميلة..."
              value={newMemory.content}
              onChange={(e) => setNewMemory(prev => ({ ...prev, content: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200 resize-none h-24"
              disabled={adding}
            />
            
            <input
              type="url"
              placeholder="رابط الصورة (اختياري)..."
              value={newMemory.imageUrl}
              onChange={(e) => setNewMemory(prev => ({ ...prev, imageUrl: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
              disabled={adding}
            />
            
            <button
              type="submit"
              disabled={adding || !newMemory.title.trim()}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {adding ? (
                <>
                  <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                  جاري الإضافة...
                </>
              ) : (
                <>
                  <Heart className="w-5 h-5 inline ml-2" />
                  حفظ الذكرى
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {/* Memories Grid */}
      {memories.length === 0 ? (
        <div className="text-center py-12">
          <Camera className="w-16 h-16 text-blue-200 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد ذكريات بعد</h3>
          <p className="text-gray-500 mb-4">ابدأ بتوثيق لحظاتكم الجميلة معاً</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors"
          >
            <Plus className="w-5 h-5 inline ml-2" />
            أول ذكرى
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {memories.map((memory) => (
            <div
              key={memory.id}
              className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl overflow-hidden border border-blue-100 hover:shadow-lg transition-all duration-300"
            >
              {memory.imageUrl && (
                <div className="h-48 bg-gray-100 relative">
                  <img
                    src={memory.imageUrl}
                    alt={memory.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none'
                    }}
                  />
                  {!memory.imageUrl && (
                    <div className="w-full h-full flex items-center justify-center">
                      <ImageIcon className="w-12 h-12 text-gray-300" />
                    </div>
                  )}
                </div>
              )}
              
              <div className="p-4">
                <div className="flex items-center mb-2">
                  <Calendar className="w-4 h-4 text-blue-500 ml-2" />
                  <span className="text-sm text-gray-500">{formatDate(memory.createdAt)}</span>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  {memory.title}
                </h3>
                
                {memory.content && (
                  <p className="text-gray-600 leading-relaxed">
                    {memory.content}
                  </p>
                )}
                
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center text-blue-600">
                    <Heart className="w-4 h-4 ml-1" fill="currentColor" />
                    <span className="text-sm">ذكرى جميلة</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Memory Stats */}
      {memories.length > 0 && (
        <div className="mt-8 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{memories.length}</div>
              <div className="text-sm text-gray-600">ذكرى جميلة</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {memories.filter(m => m.imageUrl).length}
              </div>
              <div className="text-sm text-gray-600">صورة</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">
                {memories.filter(m => m.content).length}
              </div>
              <div className="text-sm text-gray-600">قصة</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}