'use client'

import { useState, useEffect } from 'react'
import { Heart, Sparkles, Lock, MessageCircle, Gift, Music, Camera, Gamepad2, Star, LogOut, ArrowLeft } from 'lucide-react'
import { useAuth } from '@/components/auth-provider'
import { useRouter } from 'next/navigation'
import { MessagesComponent } from '@/components/messages-component'
import { LoveGamesComponent } from '@/components/love-games-component'
import { MemoriesComponent } from '@/components/memories-component'
import { WishesComponent } from '@/components/wishes-component'
import { SurprisesComponent } from '@/components/surprises-component'
import { RomanticMusic } from '@/components/romantic-music'

export default function Home() {
  const { user, login, logout, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [hearts, setHearts] = useState<Array<{id: number, left: number, delay: number}>>([])
  const [loginName, setLoginName] = useState('')
  const [loginPassword, setLoginPassword] = useState('')
  const [isLogging, setIsLogging] = useState(false)
  const [loginError, setLoginError] = useState('')
  const [currentView, setCurrentView] = useState<'dashboard' | 'messages' | 'games' | 'memories' | 'wishes' | 'surprises'>('dashboard')

  useEffect(() => {
    setMounted(true)
    const newHearts = Array.from({ length: 6 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 5
    }))
    setHearts(newHearts)
  }, [])

  useEffect(() => {
    if (user) {
      // تم تسجيل الدخول بنجاح، يمكن إعادة التوجيه للوحة التحكم
    }
  }, [user])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!loginName || !loginPassword) {
      setLoginError('الرجاء إدخال الاسم وكلمة السر')
      return
    }

    setLoginError('')
    setIsLogging(true)
    const success = await login(loginName, loginPassword)
    setIsLogging(false)
    
    if (!success) {
      setLoginError('الاسم أو كلمة السر غير صحيحة. استخدم "حبيبي" أو "ابتهال" وكلمة السر "love123"')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 flex items-center justify-center">
        <div className="text-center">
          <Heart className="w-16 h-16 text-pink-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (user) {
    if (currentView === 'messages') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
          {/* Animated Hearts Background */}
          {hearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute animate-pulse"
              style={{
                left: `${heart.left}%`,
                animationDelay: `${heart.delay}s`,
                animation: 'float 6s ease-in-out infinite'
              }}
            >
              <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
            </div>
          ))}

          <div className="relative z-10 p-4">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-pink-100 hover:bg-pink-200 text-pink-600 p-3 rounded-xl transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-red-600">
                    رسائل الحب 💕
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    {user.user1Name} ❤️ {user.user2Name}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages Component */}
            <div className="max-w-4xl mx-auto">
              <MessagesComponent />
            </div>
          </div>

          {/* Romantic Music */}
          <RomanticMusic />

          <style jsx>{`
            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              33% { transform: translateY(-20px) rotate(5deg); }
              66% { transform: translateY(10px) rotate(-5deg); }
            }
          `}</style>
        </div>
      )
    }

    if (currentView === 'games') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
          {/* Animated Hearts Background */}
          {hearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute animate-pulse"
              style={{
                left: `${heart.left}%`,
                animationDelay: `${heart.delay}s`,
                animation: 'float 6s ease-in-out infinite'
              }}
            >
              <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
            </div>
          ))}

          <div className="relative z-10 p-4">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-pink-100 hover:bg-pink-200 text-pink-600 p-3 rounded-xl transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                    ألعاب العشاق 🎮
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    {user.user1Name} ❤️ {user.user2Name}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Games Component */}
            <div className="max-w-4xl mx-auto">
              <LoveGamesComponent />
            </div>
          </div>

          {/* Romantic Music */}
          <RomanticMusic />

          <style jsx>{`
            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              33% { transform: translateY(-20px) rotate(5deg); }
              66% { transform: translateY(10px) rotate(-5deg); }
            }
          `}</style>
        </div>
      )
    }

    if (currentView === 'memories') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
          {/* Animated Hearts Background */}
          {hearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute animate-pulse"
              style={{
                left: `${heart.left}%`,
                animationDelay: `${heart.delay}s`,
                animation: 'float 6s ease-in-out infinite'
              }}
            >
              <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
            </div>
          ))}

          <div className="relative z-10 p-4">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-pink-100 hover:bg-pink-200 text-pink-600 p-3 rounded-xl transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                    ذكرياتنا 📸
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    {user.user1Name} ❤️ {user.user2Name}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Memories Component */}
            <div className="max-w-6xl mx-auto">
              <MemoriesComponent />
            </div>
          </div>

          {/* Romantic Music */}
          <RomanticMusic />

          <style jsx>{`
            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              33% { transform: translateY(-20px) rotate(5deg); }
              66% { transform: translateY(10px) rotate(-5deg); }
            }
          `}</style>
        </div>
      )
    }

    if (currentView === 'wishes') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
          {/* Animated Hearts Background */}
          {hearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute animate-pulse"
              style={{
                left: `${heart.left}%`,
                animationDelay: `${heart.delay}s`,
                animation: 'float 6s ease-in-out infinite'
              }}
            >
              <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
            </div>
          ))}

          <div className="relative z-10 p-4">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-pink-100 hover:bg-pink-200 text-pink-600 p-3 rounded-xl transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-blue-600">
                    أمنياتنا ⭐
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    {user.user1Name} ❤️ {user.user2Name}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Wishes Component */}
            <div className="max-w-4xl mx-auto">
              <WishesComponent />
            </div>
          </div>

          {/* Romantic Music */}
          <RomanticMusic />

          <style jsx>{`
            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              33% { transform: translateY(-20px) rotate(5deg); }
              66% { transform: translateY(10px) rotate(-5deg); }
            }
          `}</style>
        </div>
      )
    }

    if (currentView === 'surprises') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
          {/* Animated Hearts Background */}
          {hearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute animate-pulse"
              style={{
                left: `${heart.left}%`,
                animationDelay: `${heart.delay}s`,
                animation: 'float 6s ease-in-out infinite'
              }}
            >
              <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
            </div>
          ))}

          <div className="relative z-10 p-4">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-pink-100 hover:bg-pink-200 text-pink-600 p-3 rounded-xl transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-center flex-1">
                  <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-600 to-pink-600">
                    مفاجآت 🎁
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    {user.user1Name} ❤️ {user.user2Name}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Surprises Component */}
            <div className="max-w-4xl mx-auto">
              <SurprisesComponent />
            </div>
          </div>

          {/* Romantic Music */}
          <RomanticMusic />

          <style jsx>{`
            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              33% { transform: translateY(-20px) rotate(5deg); }
              66% { transform: translateY(10px) rotate(-5deg); }
            }
          `}</style>
        </div>
      )
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
        {/* Animated Hearts Background */}
        {hearts.map((heart) => (
          <div
            key={heart.id}
            className="absolute animate-pulse"
            style={{
              left: `${heart.left}%`,
              animationDelay: `${heart.delay}s`,
              animation: 'float 6s ease-in-out infinite'
            }}
          >
            <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
          </div>
        ))}

        {/* Dashboard */}
        <div className="relative z-10 p-4">
          {/* Header */}
          <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-xl p-6 mb-8 border border-pink-100">
            <div className="flex justify-between items-center">
              <div className="text-center flex-1">
                <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-red-600 mb-2">
                  عالمنا السري 💕
                </h1>
                <p className="text-gray-700">
                  مرحباً بكِ يا {user.currentUserName === user.user1Name ? user.user2Name : user.user1Name}!
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {user.user1Name} ❤️ {user.user2Name}
                </p>
              </div>
              <button
                onClick={logout}
                className="bg-red-100 hover:bg-red-200 text-red-600 p-3 rounded-xl transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Main Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div 
              onClick={() => setCurrentView('messages')}
              className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer"
            >
              <MessageCircle className="w-12 h-12 text-pink-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">رسائل الحب</h3>
              <p className="text-gray-600 mb-4">اكتبي رسائلكِ الرومانسية</p>
              <div className="bg-pink-50 rounded-lg p-3">
                <p className="text-sm text-pink-700">آخر رسالة: "أحبكِ أكثر من أي شيء"</p>
              </div>
            </div>

            <div 
              onClick={() => setCurrentView('games')}
              className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer"
            >
              <Gamepad2 className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">ألعاب العشاق</h3>
              <p className="text-gray-600 mb-4">العبوا معاً وتسليوا</p>
              <div className="bg-purple-50 rounded-lg p-3">
                <p className="text-sm text-purple-700">لعبة اليوم: اسئلة الحب</p>
              </div>
            </div>

            <div 
              onClick={() => setCurrentView('memories')}
              className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer"
            >
              <Camera className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">ذكرياتنا</h3>
              <p className="text-gray-600 mb-4">صور ولحظات حب</p>
              <div className="bg-blue-50 rounded-lg p-3">
                <p className="text-sm text-blue-700">عدد الذكريات: 2 ذكرى جميلة</p>
              </div>
            </div>

            <div 
              onClick={() => setCurrentView('surprises')}
              className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer"
            >
              <Gift className="w-12 h-12 text-yellow-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">مفاجآت</h3>
              <p className="text-gray-600 mb-4">هدايا ومفاجآت رومانسية</p>
              <div className="bg-yellow-50 rounded-lg p-3">
                <p className="text-sm text-yellow-700">مفاجأة جديدة في انتظاركِ!</p>
              </div>
            </div>

            <div 
              onClick={() => setCurrentView('wishes')}
              className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer"
            >
              <Star className="w-12 h-12 text-green-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">أمنياتنا</h3>
              <p className="text-gray-600 mb-4">أحلام وتمنيات مشتركة</p>
              <div className="bg-green-50 rounded-lg p-3">
                <p className="text-sm text-green-700">أمنية محققة: 1 من 3</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 transform hover:scale-105 border border-pink-100 cursor-pointer">
              <Music className="w-12 h-12 text-indigo-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">أغاني الحب</h3>
              <p className="text-gray-600 mb-4">أغنينا المفضلة</p>
              <div className="bg-indigo-50 rounded-lg p-3">
                <p className="text-sm text-indigo-700">قائمة التشغيل: 15 أغنية</p>
              </div>
            </div>
          </div>

          {/* Romantic Quote */}
          <div className="mt-12 text-center max-w-2xl mx-auto">
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-pink-100">
              <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <p className="text-lg text-gray-700 italic">
                "أنتِ نور عيني، ودفء قلبي، وكل ما أتمناه في هذه الحياة"
              </p>
              <p className="text-sm text-gray-600 mt-2">- من {user.currentUserName} إلى حبيبته الأبدية</p>
            </div>
          </div>
        </div>

        <style jsx>{`
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-20px) rotate(5deg); }
            66% { transform: translateY(10px) rotate(-5deg); }
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 relative overflow-hidden">
      {/* Animated Hearts Background */}
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute animate-pulse"
          style={{
            left: `${heart.left}%`,
            animationDelay: `${heart.delay}s`,
            animation: 'float 6s ease-in-out infinite'
          }}
        >
          <Heart className="w-8 h-8 text-pink-200 opacity-60" fill="currentColor" />
        </div>
      ))}

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4">
        {/* Romantic Header */}
        <div className="text-center mb-12 animate-fade-in">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Heart className="w-16 h-16 text-red-500 animate-pulse" fill="currentColor" />
              <Sparkles className="w-8 h-8 text-yellow-400 absolute -top-2 -right-2 animate-spin" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-red-600 mb-4">
            عالم ابتهال
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-2">
            المكان الذي يلتقي فيه القلبان
          </p>
          
          <p className="text-lg text-gray-600 italic">
            "حبيبتي ابتهال، حبك هو نور حياتي"
          </p>
        </div>

        {/* Login Section */}
        <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8 max-w-md w-full border border-pink-100">
          <div className="text-center mb-6">
            <Lock className="w-12 h-12 text-pink-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-800 mb-2">
              مساحة خاصة بنا
            </h2>
            <p className="text-gray-600 mb-4">
              فقط أنا وابتهال يمكننا الدخول إلى عالمنا السري
            </p>
            <div className="bg-pink-50 border border-pink-200 rounded-lg p-3 text-sm">
              <p className="text-pink-700 font-medium mb-1">بيانات الدخول:</p>
              <p className="text-pink-600">الاسم: "حبيبي" أو "ابتهال"</p>
              <p className="text-pink-600">كلمة السر: love123</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {loginError}
              </div>
            )}
            <input
              type="text"
              placeholder="اسمك الجميل"
              value={loginName}
              onChange={(e) => setLoginName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 text-center"
              disabled={isLogging}
            />
            <input
              type="password"
              placeholder="كلمة السر السرية"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 text-center"
              disabled={isLogging}
            />
            <button 
              type="submit"
              disabled={isLogging}
              className="w-full bg-gradient-to-r from-pink-500 to-red-500 text-white py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLogging ? (
                <>
                  <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                  جاري الدخول...
                </>
              ) : (
                <>
                  <Heart className="w-5 h-5 inline ml-2" />
                  ادخل إلى عالمنا
                </>
              )}
            </button>
          </form>
        </div>

        {/* Features Preview */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl w-full">
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center hover:bg-white/80 transition-all duration-300 transform hover:scale-105">
            <MessageCircle className="w-10 h-10 text-pink-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-800">رسائل الحب</h3>
            <p className="text-sm text-gray-600 mt-1">كلماتنا الرومانسية</p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center hover:bg-white/80 transition-all duration-300 transform hover:scale-105">
            <Gamepad2 className="w-10 h-10 text-purple-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-800">ألعاب العشاق</h3>
            <p className="text-sm text-gray-600 mt-1">مرح وقربان</p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center hover:bg-white/80 transition-all duration-300 transform hover:scale-105">
            <Camera className="w-10 h-10 text-blue-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-800">ذكرياتنا</h3>
            <p className="text-sm text-gray-600 mt-1">صور ولحظات حب</p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center hover:bg-white/80 transition-all duration-300 transform hover:scale-105">
            <Gift className="w-10 h-10 text-yellow-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-800">مفاجآت</h3>
            <p className="text-sm text-gray-600 mt-1">هدايا رومانسية</p>
          </div>
        </div>

        {/* Romantic Quote */}
        <div className="mt-12 text-center max-w-2xl">
          <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 border border-pink-100">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
            <p className="text-lg text-gray-700 italic">
              "في عينيكِ يا ابتهال، أرى مستقبلي وحاضري وكل ما أتمناه في هذه الحياة"
            </p>
            <p className="text-sm text-gray-600 mt-2">- إلى حبيبتي الأبدية</p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-20px) rotate(5deg); }
          66% { transform: translateY(10px) rotate(-5deg); }
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
      `}</style>
    </div>
  )
}