'use client'

import { useState, useEffect } from 'react'
import { Heart, Gamepad2, Sparkles, Trophy, RotateCcw } from 'lucide-react'

interface Question {
  id: number
  question: string
  category: string
}

interface GameScore {
  id: string
  gameName: string
  player: string
  score: number
  createdAt: string
}

const loveQuestions: Question[] = [
  { id: 1, question: "ما هي أجمل صفة تحبينها في شريكك؟", category: "الصفات الحميدة" },
  { id: 2, question: "ما هي أجمل ذكرى معاً؟", category: "الذكريات" },
  { id: 3, question: "ما هو الشيء الذي يجعلك تضحكين معه؟", category: "المرح" },
  { id: 4, question: "كيف تصفين حبك له في كلمة واحدة؟", category: "الحب" },
  { id: 5, question: "ما هو أحلامكما المشتركة؟", category: "الأحلام" },
  { id: 6, question: "ما هي أغنية الحب المفضلة لكما؟", category: "الموسيقى" },
  { id: 7, question: "ما هو أول شيء لاحظته فيه؟", category: "الانطباعات" },
  { id: 8, question: "ما هي اللحظة التي شعرتِ فيها أنه الحب؟", category: "اللحظات" },
  { id: 9, question: "ما هو الشيء الذي تقدرينه فيه أكثر؟", category: "التقدير" },
  { id: 10, question: "كيف تتخيلين حياتكما بعد 10 سنوات؟", category: "المستقبل" }
]

export function LoveGamesComponent() {
  const [currentGame, setCurrentGame] = useState<'menu' | 'questions' | 'compatibility' | 'memory'>('menu')
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])
  const [gameScores, setGameScores] = useState<GameScore[]>([])
  const [loading, setLoading] = useState(true)
  const [currentAnswer, setCurrentAnswer] = useState('')

  useEffect(() => {
    fetchGameScores()
  }, [])

  const fetchGameScores = async () => {
    try {
      const response = await fetch('/api/games/scores')
      if (response.ok) {
        const data = await response.json()
        setGameScores(data)
      }
    } catch (error) {
      console.error('Failed to fetch game scores:', error)
    } finally {
      setLoading(false)
    }
  }

  const saveGameScore = async (gameName: string, score: number) => {
    try {
      const response = await fetch('/api/games/scores', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ gameName, score }),
      })

      if (response.ok) {
        const newScore = await response.json()
        setGameScores(prev => [newScore, ...prev])
      }
    } catch (error) {
      console.error('Failed to save game score:', error)
    }
  }

  const handleAnswerSubmit = () => {
    if (!currentAnswer.trim()) return

    const newAnswers = [...answers, currentAnswer]
    setAnswers(newAnswers)
    setCurrentAnswer('')

    if (currentQuestionIndex < loveQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      // Game completed
      saveGameScore('أسئلة الحب', newAnswers.length)
      setCurrentGame('menu')
      setCurrentQuestionIndex(0)
      setAnswers([])
    }
  }

  const resetGame = () => {
    setCurrentQuestionIndex(0)
    setAnswers([])
    setCurrentAnswer('')
    setCurrentGame('menu')
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ar-EG', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="text-center">
          <Gamepad2 className="w-12 h-12 text-purple-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري تحميل الألعاب...</p>
        </div>
      </div>
    )
  }

  if (currentGame === 'questions') {
    const currentQuestion = loveQuestions[currentQuestionIndex]
    const progress = ((currentQuestionIndex + 1) / loveQuestions.length) * 100

    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Heart className="w-8 h-8 text-pink-500 ml-3" fill="currentColor" />
            <h2 className="text-2xl font-bold text-gray-800">أسئلة الحب</h2>
          </div>
          <button
            onClick={resetGame}
            className="bg-gray-100 hover:bg-gray-200 text-gray-600 p-2 rounded-lg transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>السؤال {currentQuestionIndex + 1} من {loveQuestions.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-pink-500 to-red-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-6 mb-6 border border-pink-100">
          <div className="flex items-center mb-3">
            <Sparkles className="w-5 h-5 text-yellow-500 ml-2" />
            <span className="text-sm font-semibold text-pink-600">{currentQuestion.category}</span>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-4">
            {currentQuestion.question}
          </h3>
          
          <textarea
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            placeholder="اكتبي إجابتك من القلب..."
            className="w-full px-4 py-3 rounded-lg border border-pink-200 focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 resize-none h-24"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <button
            onClick={handleAnswerSubmit}
            disabled={!currentAnswer.trim()}
            className="flex-1 bg-gradient-to-r from-pink-500 to-red-500 text-white py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {currentQuestionIndex === loveQuestions.length - 1 ? 'إنهاء اللعبة' : 'السؤال التالي'}
          </button>
        </div>

        {/* Previous Answers */}
        {answers.length > 0 && (
          <div className="mt-6">
            <h4 className="font-semibold text-gray-700 mb-3">إجاباتك السابقة:</h4>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {answers.map((answer, index) => (
                <div key={index} className="bg-pink-50 rounded-lg p-3 text-sm text-gray-700">
                  <span className="font-semibold text-pink-600">السؤال {index + 1}:</span> {answer}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
      <div className="flex items-center mb-6">
        <Gamepad2 className="w-8 h-8 text-purple-500 ml-3" />
        <h2 className="text-2xl font-bold text-gray-800">ألعاب العشاق</h2>
      </div>

      {/* Games Menu */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div 
          onClick={() => setCurrentGame('questions')}
          className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-6 border border-pink-100 cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105"
        >
          <div className="flex items-center mb-4">
            <Heart className="w-8 h-8 text-pink-500 ml-3" fill="currentColor" />
            <h3 className="text-lg font-semibold text-gray-800">أسئلة الحب</h3>
          </div>
          <p className="text-gray-600 mb-4">أجوبوا على أسئلة رومانسية وتعرفوا على بعضكم أكثر</p>
          <div className="flex items-center text-pink-600">
            <span className="text-sm font-semibold">ابدأ اللعبة</span>
            <Heart className="w-4 h-4 mr-2" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100 cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105 opacity-75">
          <div className="flex items-center mb-4">
            <Sparkles className="w-8 h-8 text-purple-500 ml-3" />
            <h3 className="text-lg font-semibold text-gray-800">التوافق الروحي</h3>
          </div>
          <p className="text-gray-600 mb-4">اختبروا مدى توافقكم الروحي والعاطفي</p>
          <div className="flex items-center text-purple-600">
            <span className="text-sm font-semibold">قريباً</span>
            <Sparkles className="w-4 h-4 mr-2" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-100 cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105 opacity-75">
          <div className="flex items-center mb-4">
            <Trophy className="w-8 h-8 text-blue-500 ml-3" />
            <h3 className="text-lg font-semibold text-gray-800">ذاكرة الحب</h3>
          </div>
          <p className="text-gray-600 mb-4">لعبة ذاكرة مع صور ولحظاتكم الجميلة</p>
          <div className="flex items-center text-blue-600">
            <span className="text-sm font-semibold">قريباً</span>
            <Trophy className="w-4 h-4 mr-2" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-100 cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105 opacity-75">
          <div className="flex items-center mb-4">
            <Gamepad2 className="w-8 h-8 text-yellow-500 ml-3" />
            <h3 className="text-lg font-semibold text-gray-800">تحدي الأزواج</h3>
          </div>
          <p className="text-gray-600 mb-4">تحديات مسلية ومضحكة للأزواج</p>
          <div className="flex items-center text-yellow-600">
            <span className="text-sm font-semibold">قريباً</span>
            <Gamepad2 className="w-4 h-4 mr-2" />
          </div>
        </div>
      </div>

      {/* Game Scores */}
      <div className="bg-purple-50 rounded-xl p-4">
        <h3 className="font-semibold text-purple-700 mb-3 flex items-center">
          <Trophy className="w-5 h-5 ml-2" />
          أحدث النتائج
        </h3>
        {gameScores.length === 0 ? (
          <p className="text-gray-500 text-sm">لا توجد نتائج بعد. ابدأ اللعب!</p>
        ) : (
          <div className="space-y-2">
            {gameScores.slice(0, 5).map((score) => (
              <div key={score.id} className="flex justify-between items-center bg-white rounded-lg p-2">
                <div>
                  <span className="font-semibold text-gray-700">{score.gameName}</span>
                  <span className="text-sm text-gray-500 mr-2">- {score.player}</span>
                </div>
                <div className="text-left">
                  <span className="font-bold text-purple-600">{score.score}</span>
                  <span className="text-xs text-gray-400 mr-2">{formatDate(score.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}