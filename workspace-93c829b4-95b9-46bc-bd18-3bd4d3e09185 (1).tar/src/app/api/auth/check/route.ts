import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value
    const currentUserName = request.cookies.get('currentUserName')?.value

    if (!coupleId || !currentUserName) {
      return NextResponse.json(
        { error: 'غير مصدق' },
        { status: 401 }
      )
    }

    // هنا يمكن التحقق من قاعدة البيانات إذا كان الزوجان لا يزالان موجودين
    // للتبسيط، سنعيد البيانات من الكوكيز

    return NextResponse.json({
      coupleId,
      currentUserName,
      // يمكن إضافة المزيد من البيانات من قاعدة البيانات
    })

  } catch (error) {
    console.error('Auth check error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}