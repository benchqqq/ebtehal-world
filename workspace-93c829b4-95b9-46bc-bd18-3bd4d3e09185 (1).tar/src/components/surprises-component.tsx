'use client'

import { useState, useEffect } from 'react'
import { Gift, Plus, Eye, EyeOff, Sparkles, Lock, Unlock } from 'lucide-react'

interface Surprise {
  id: string
  title: string
  content: string
  revealed: boolean
  createdAt: string
}

export function SurprisesComponent() {
  const [surprises, setSurprises] = useState<Surprise[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newSurprise, setNewSurprise] = useState({
    title: '',
    content: ''
  })
  const [adding, setAdding] = useState(false)

  useEffect(() => {
    fetchSurprises()
  }, [])

  const fetchSurprises = async () => {
    try {
      const response = await fetch('/api/surprises')
      if (response.ok) {
        const data = await response.json()
        setSurprises(data)
      }
    } catch (error) {
      console.error('Failed to fetch surprises:', error)
    } finally {
      setLoading(false)
    }
  }

  const addSurprise = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newSurprise.title.trim() || !newSurprise.content.trim()) return

    setAdding(true)
    try {
      const response = await fetch('/api/surprises', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newSurprise),
      })

      if (response.ok) {
        const surprise = await response.json()
        setSurprises(prev => [surprise, ...prev])
        setNewSurprise({ title: '', content: '' })
        setShowAddForm(false)
      } else {
        const error = await response.json()
        alert(error.error || 'فشل إضافة المفاجأة')
      }
    } catch (error) {
      console.error('Failed to add surprise:', error)
      alert('حدث خطأ ما')
    } finally {
      setAdding(false)
    }
  }

  const toggleSurpriseRevealed = async (surpriseId: string, revealed: boolean) => {
    try {
      const response = await fetch('/api/surprises', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ surpriseId, revealed }),
      })

      if (response.ok) {
        const updatedSurprise = await response.json()
        setSurprises(prev => 
          prev.map(surprise => surprise.id === surpriseId ? updatedSurprise : surprise)
        )
      } else {
        const error = await response.json()
        alert(error.error || 'فشل تحديث المفاجأة')
      }
    } catch (error) {
      console.error('Failed to update surprise:', error)
      alert('حدث خطأ ما')
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  const revealedCount = surprises.filter(s => s.revealed).length
  const hiddenCount = surprises.filter(s => !s.revealed).length

  if (loading) {
    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="text-center">
          <Gift className="w-12 h-12 text-yellow-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري تحميل المفاجآت...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Gift className="w-8 h-8 text-yellow-500 ml-3" />
          <h2 className="text-2xl font-bold text-gray-800">مفاجآت</h2>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-yellow-500 hover:bg-yellow-600 text-white p-3 rounded-xl transition-colors shadow-lg"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-yellow-600">{hiddenCount}</div>
          <div className="text-sm text-gray-600">مفاجآت مخفية</div>
        </div>
        <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-pink-600">{revealedCount}</div>
          <div className="text-sm text-gray-600">مفاجآت مكشوفة</div>
        </div>
      </div>

      {/* Add Surprise Form */}
      {showAddForm && (
        <div className="bg-gradient-to-r from-yellow-50 to-pink-50 rounded-xl p-6 mb-6 border border-yellow-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">مفاجأة جديدة</h3>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <EyeOff className="w-5 h-5" />
            </button>
          </div>
          
          <form onSubmit={addSurprise} className="space-y-4">
            <input
              type="text"
              placeholder="عنوان المفاجأة..."
              value={newSurprise.title}
              onChange={(e) => setNewSurprise(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-yellow-200 focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-200"
              disabled={adding}
            />
            
            <textarea
              placeholder="محتوى المفاجأة الرومانسية..."
              value={newSurprise.content}
              onChange={(e) => setNewSurprise(prev => ({ ...prev, content: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-yellow-200 focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-200 resize-none h-24"
              disabled={adding}
            />
            
            <button
              type="submit"
              disabled={adding || !newSurprise.title.trim() || !newSurprise.content.trim()}
              className="w-full bg-gradient-to-r from-yellow-500 to-pink-500 text-white py-3 rounded-xl font-semibold hover:from-yellow-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {adding ? (
                <>
                  <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                  جاري الإضافة...
                </>
              ) : (
                <>
                  <Gift className="w-5 h-5 inline ml-2" />
                  إخفاء المفاجأة
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {/* Surprises List */}
      {surprises.length === 0 ? (
        <div className="text-center py-12">
          <Gift className="w-16 h-16 text-yellow-200 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد مفاجآت بعد</h3>
          <p className="text-gray-500 mb-4">أضيفي بعض المفاجآت الرومانسية</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors"
          >
            <Plus className="w-5 h-5 inline ml-2" />
            أول مفاجأة
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {surprises.map((surprise) => (
            <div
              key={surprise.id}
              className={`rounded-xl p-4 border transition-all duration-300 ${
                surprise.revealed
                  ? 'bg-gradient-to-r from-pink-50 to-rose-50 border-pink-200'
                  : 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    {surprise.revealed ? (
                      <Unlock className="w-5 h-5 text-pink-600 ml-2" />
                    ) : (
                      <Lock className="w-5 h-5 text-yellow-600 ml-2" />
                    )}
                    <span className={`text-sm font-semibold ${
                      surprise.revealed ? 'text-pink-600' : 'text-yellow-600'
                    }`}>
                      {surprise.revealed ? 'مكشوفة' : 'مخفية'}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">
                    {surprise.title}
                  </h3>
                  
                  {surprise.revealed ? (
                    <div className="bg-white/70 rounded-lg p-3 mb-3">
                      <p className="text-gray-700 leading-relaxed">
                        {surprise.content}
                      </p>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-lg p-3 mb-3">
                      <div className="flex items-center justify-center py-4">
                        <Lock className="w-8 h-8 text-yellow-600 mr-3" />
                        <span className="text-yellow-700 font-semibold">مفاجأة مخفية</span>
                        <Sparkles className="w-6 h-6 text-yellow-500 ml-3 animate-pulse" />
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-center text-sm text-gray-500">
                    <Gift className="w-4 h-4 ml-1" />
                    {formatDate(surprise.createdAt)}
                  </div>
                </div>
                
                <button
                  onClick={() => toggleSurpriseRevealed(surprise.id, !surprise.revealed)}
                  className={`p-2 rounded-lg transition-colors ${
                    surprise.revealed
                      ? 'bg-pink-100 hover:bg-pink-200 text-pink-600'
                      : 'bg-yellow-100 hover:bg-yellow-200 text-yellow-600'
                  }`}
                >
                  {surprise.revealed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Surprise Ideas */}
      <div className="mt-8 bg-gradient-to-r from-yellow-100 to-pink-100 rounded-xl p-4">
        <h3 className="font-semibold text-yellow-700 mb-3 flex items-center">
          <Sparkles className="w-5 h-5 ml-2" />
          أفكار للمفاجآت
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <div className="text-sm text-gray-600">
            💝 رسالة حب في زجاجة
          </div>
          <div className="text-sm text-gray-600">
            🌹 وردة مع كلمة جميلة
          </div>
          <div className="text-sm text-gray-600">
            🍰 كيك حب مفاجأة
          </div>
          <div className="text-sm text-gray-600">
            🎫 تذاكر لمكان تحبونه
          </div>
        </div>
      </div>
    </div>
  )
}