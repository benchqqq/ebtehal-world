import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST() {
  try {
    // التحقق مما إذا كان هناك زوجان بالفعل
    const existingCouple = await db.couple.findFirst()
    
    if (existingCouple) {
      return NextResponse.json({
        message: 'تم إعداد الزوجين بالفعل',
        couple: {
          name1: existingCouple.name1,
          name2: existingCouple.name2
        }
      })
    }

    // إنشاء كلمة سر مشفرة
    const hashedPassword = await bcrypt.hash('love123', 10)

    // إنشاء زوجين جدد
    const couple = await db.couple.create({
      data: {
        name1: 'حبيبي',
        name2: 'ابتهال',
        password: hashedPassword
      }
    })

    // إضافة بعض الرسائل الأولية
    await db.message.createMany({
      data: [
        {
          content: 'أحبكِ يا ابتهال أكثر من الكلمات يمكن أن تعبر',
          sender: 'حبيبي',
          coupleId: couple.id
        },
        {
          content: 'وأنا أيضاً أحبكِ يا حبيبي، أنت كل حياتي',
          sender: 'ابتهال',
          coupleId: couple.id
        },
        {
          content: 'كل لحظة معكِ هي جنة في الأرض',
          sender: 'حبيبي',
          coupleId: couple.id
        }
      ]
    })

    // إضافة بعض الذكريات
    await db.memory.createMany({
      data: [
        {
          title: 'لقائنا الأول',
          content: 'أجمل يوم في حياتي عندما رأيتكِ لأول مرة',
          coupleId: couple.id
        },
        {
          title: 'المشي في الحديقة',
          content: 'ذكرياتنا الجميلة معاً تحت ضوء القمر',
          coupleId: couple.id
        }
      ]
    })

    // إضافة بعض الأمنيات
    await db.wish.createMany({
      data: [
        {
          content: 'أن نعيش معاً إلى الأبد',
          fulfilled: false,
          coupleId: couple.id
        },
        {
          content: 'السفر حول العالم معاً',
          fulfilled: false,
          coupleId: couple.id
        },
        {
          content: 'بناء بيتنا الصغير',
          fulfilled: true,
          coupleId: couple.id
        }
      ]
    })

    return NextResponse.json({
      message: 'تم إعداد الزوجين والبيانات الأولية بنجاح',
      couple: {
        name1: couple.name1,
        name2: couple.name2,
        loginInfo: {
          names: ['حبيبي', 'ابتهال'],
          password: 'love123'
        }
      }
    })

  } catch (error) {
    console.error('Setup error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء الإعداد' },
      { status: 500 }
    )
  }
}