import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const surprises = await db.surprise.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(surprises)

  } catch (error) {
    console.error('Get surprises error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { title, content } = await request.json()

    if (!title || title.trim().length === 0) {
      return NextResponse.json(
        { error: 'عنوان المفاجأة مطلوب' },
        { status: 400 }
      )
    }

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'محتوى المفاجأة مطلوب' },
        { status: 400 }
      )
    }

    const surprise = await db.surprise.create({
      data: {
        title: title.trim(),
        content: content.trim(),
        coupleId
      }
    })

    return NextResponse.json(surprise)

  } catch (error) {
    console.error('Create surprise error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { surpriseId, revealed } = await request.json()

    if (!surpriseId) {
      return NextResponse.json(
        { error: 'معرف المفاجأة مطلوب' },
        { status: 400 }
      )
    }

    const surprise = await db.surprise.update({
      where: { 
        id: surpriseId,
        coupleId 
      },
      data: { revealed }
    })

    return NextResponse.json(surprise)

  } catch (error) {
    console.error('Update surprise error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}