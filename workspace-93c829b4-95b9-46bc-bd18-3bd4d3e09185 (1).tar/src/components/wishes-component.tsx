'use client'

import { useState, useEffect } from 'react'
import { Star, Plus, Check, X, Sparkles, Target } from 'lucide-react'

interface Wish {
  id: string
  content: string
  fulfilled: boolean
  createdAt: string
}

export function WishesComponent() {
  const [wishes, setWishes] = useState<Wish[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newWish, setNewWish] = useState('')
  const [adding, setAdding] = useState(false)

  useEffect(() => {
    fetchWishes()
  }, [])

  const fetchWishes = async () => {
    try {
      const response = await fetch('/api/wishes')
      if (response.ok) {
        const data = await response.json()
        setWishes(data)
      }
    } catch (error) {
      console.error('Failed to fetch wishes:', error)
    } finally {
      setLoading(false)
    }
  }

  const addWish = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newWish.trim()) return

    setAdding(true)
    try {
      const response = await fetch('/api/wishes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: newWish }),
      })

      if (response.ok) {
        const wish = await response.json()
        setWishes(prev => [wish, ...prev])
        setNewWish('')
        setShowAddForm(false)
      } else {
        const error = await response.json()
        alert(error.error || 'فشل إضافة الأمنية')
      }
    } catch (error) {
      console.error('Failed to add wish:', error)
      alert('حدث خطأ ما')
    } finally {
      setAdding(false)
    }
  }

  const toggleWishFulfilled = async (wishId: string, fulfilled: boolean) => {
    try {
      const response = await fetch('/api/wishes', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wishId, fulfilled }),
      })

      if (response.ok) {
        const updatedWish = await response.json()
        setWishes(prev => 
          prev.map(wish => wish.id === wishId ? updatedWish : wish)
        )
      } else {
        const error = await response.json()
        alert(error.error || 'فشل تحديث الأمنية')
      }
    } catch (error) {
      console.error('Failed to update wish:', error)
      alert('حدث خطأ ما')
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  const fulfilledCount = wishes.filter(w => w.fulfilled).length
  const pendingCount = wishes.filter(w => !w.fulfilled).length

  if (loading) {
    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="text-center">
          <Star className="w-12 h-12 text-green-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري تحميل الأمنيات...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Star className="w-8 h-8 text-green-500 ml-3" />
          <h2 className="text-2xl font-bold text-gray-800">أمنياتنا</h2>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-500 hover:bg-green-600 text-white p-3 rounded-xl transition-colors shadow-lg"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{wishes.length}</div>
          <div className="text-sm text-gray-600">إجمالي الأمنيات</div>
        </div>
        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{pendingCount}</div>
          <div className="text-sm text-gray-600">تنتظر التحقيق</div>
        </div>
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-yellow-600">{fulfilledCount}</div>
          <div className="text-sm text-gray-600">تم تحقيقها</div>
        </div>
      </div>

      {/* Add Wish Form */}
      {showAddForm && (
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 mb-6 border border-green-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">أمنية جديدة</h3>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <form onSubmit={addWish} className="space-y-4">
            <textarea
              placeholder="اكتبي أمنيتكم الجميلة..."
              value={newWish}
              onChange={(e) => setNewWish(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-green-200 focus:border-green-400 focus:outline-none focus:ring-2 focus:ring-green-200 resize-none h-24"
              disabled={adding}
            />
            
            <button
              type="submit"
              disabled={adding || !newWish.trim()}
              className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 rounded-xl font-semibold hover:from-green-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {adding ? (
                <>
                  <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                  جاري الإضافة...
                </>
              ) : (
                <>
                  <Star className="w-5 h-5 inline ml-2" />
                  أضف أمنية
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {/* Wishes List */}
      {wishes.length === 0 ? (
        <div className="text-center py-12">
          <Star className="w-16 h-16 text-green-200 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد أمنيات بعد</h3>
          <p className="text-gray-500 mb-4">ابدأوا بالحلم معاً</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors"
          >
            <Plus className="w-5 h-5 inline ml-2" />
            أول أمنية
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {wishes.map((wish) => (
            <div
              key={wish.id}
              className={`rounded-xl p-4 border transition-all duration-300 ${
                wish.fulfilled
                  ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200'
                  : 'bg-gradient-to-r from-blue-50 to-green-50 border-blue-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    {wish.fulfilled ? (
                      <Check className="w-5 h-5 text-yellow-600 ml-2" />
                    ) : (
                      <Target className="w-5 h-5 text-blue-600 ml-2" />
                    )}
                    <span className={`text-sm ${
                      wish.fulfilled ? 'text-yellow-600' : 'text-blue-600'
                    }`}>
                      {wish.fulfilled ? 'تم تحقيقها' : 'تنتظر التحقيق'}
                    </span>
                  </div>
                  
                  <p className={`text-gray-800 leading-relaxed ${
                    wish.fulfilled ? 'line-through opacity-75' : ''
                  }`}>
                    {wish.content}
                  </p>
                  
                  <div className="flex items-center mt-3 text-sm text-gray-500">
                    <Sparkles className="w-4 h-4 ml-1" />
                    {formatDate(wish.createdAt)}
                  </div>
                </div>
                
                <button
                  onClick={() => toggleWishFulfilled(wish.id, !wish.fulfilled)}
                  className={`p-2 rounded-lg transition-colors ${
                    wish.fulfilled
                      ? 'bg-yellow-100 hover:bg-yellow-200 text-yellow-600'
                      : 'bg-blue-100 hover:bg-blue-200 text-blue-600'
                  }`}
                >
                  {wish.fulfilled ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Progress */}
      {wishes.length > 0 && (
        <div className="mt-8 bg-gradient-to-r from-green-100 to-blue-100 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-gray-700">مستوى تحقيق الأمنيات</span>
            <span className="text-sm font-bold text-green-600">
              {Math.round((fulfilledCount / wishes.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(fulfilledCount / wishes.length) * 100}%` }}
            />
          </div>
          <p className="text-center text-sm text-gray-600 mt-2">
            {fulfilledCount} من {wishes.length} أمنية تحققت ✨
          </p>
        </div>
      )}
    </div>
  )
}