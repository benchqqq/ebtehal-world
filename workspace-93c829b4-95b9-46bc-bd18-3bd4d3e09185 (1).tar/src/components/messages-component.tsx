'use client'

import { useState, useEffect } from 'react'
import { Heart, Send, MessageCircle } from 'lucide-react'

interface Message {
  id: string
  content: string
  sender: string
  createdAt: string
}

export function MessagesComponent() {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)

  useEffect(() => {
    fetchMessages()
  }, [])

  const fetchMessages = async () => {
    try {
      const response = await fetch('/api/messages')
      if (response.ok) {
        const data = await response.json()
        setMessages(data)
      }
    } catch (error) {
      console.error('Failed to fetch messages:', error)
    } finally {
      setLoading(false)
    }
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    setSending(true)
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: newMessage }),
      })

      if (response.ok) {
        const message = await response.json()
        setMessages(prev => [message, ...prev])
        setNewMessage('')
      } else {
        const error = await response.json()
        alert(error.error || 'فشل إرسال الرسالة')
      }
    } catch (error) {
      console.error('Failed to send message:', error)
      alert('حدث خطأ ما')
    } finally {
      setSending(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
        <div className="text-center">
          <MessageCircle className="w-12 h-12 text-pink-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">جاري تحميل رسائل الحب...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-pink-100">
      <div className="flex items-center mb-6">
        <Heart className="w-8 h-8 text-pink-500 ml-3" fill="currentColor" />
        <h2 className="text-2xl font-bold text-gray-800">رسائل الحب</h2>
      </div>

      {/* Messages List */}
      <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <Heart className="w-16 h-16 text-pink-200 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد رسائل بعد</p>
            <p className="text-sm text-gray-400 mt-2">ابدأ بكتابة أول رسالة حب</p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-4 border border-pink-100"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-semibold text-pink-700">
                  {message.sender}
                </span>
                <span className="text-xs text-gray-500">
                  {formatDate(message.createdAt)}
                </span>
              </div>
              <p className="text-gray-700 leading-relaxed">
                {message.content}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Send Message Form */}
      <form onSubmit={sendMessage} className="space-y-4">
        <div className="relative">
          <textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="اكتبي رسالة حب جميلة..."
            className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 resize-none h-24"
            disabled={sending}
          />
          <div className="absolute bottom-2 left-2 text-sm text-gray-400">
            {newMessage.length}/500
          </div>
        </div>
        <button
          type="submit"
          disabled={sending || !newMessage.trim()}
          className="w-full bg-gradient-to-r from-pink-500 to-red-500 text-white py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {sending ? (
            <>
              <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
              جاري الإرسال...
            </>
          ) : (
            <>
              <Send className="w-5 h-5 ml-2" />
              أرسل رسالة الحب
            </>
          )}
        </button>
      </form>

      {/* Romantic Suggestions */}
      <div className="mt-6 p-4 bg-pink-50 rounded-xl">
        <h3 className="font-semibold text-pink-700 mb-2">اقتراحات رومانسية:</h3>
        <div className="space-y-2">
          <button 
            onClick={() => setNewMessage('أحبكِ أكثر من أي شيء في هذا العالم')}
            className="w-full text-right text-sm text-gray-600 hover:text-pink-600 transition-colors"
          >
            💕 "أحبكِ أكثر من أي شيء في هذا العالم"
          </button>
          <button 
            onClick={() => setNewMessage('أنتِ نور عيني ودفء قلبي')}
            className="w-full text-right text-sm text-gray-600 hover:text-pink-600 transition-colors"
          >
            💕 "أنتِ نور عيني ودفء قلبي"
          </button>
          <button 
            onClick={() => setNewMessage('كل لحظة معكِ هي جنة')}
            className="w-full text-right text-sm text-gray-600 hover:text-pink-600 transition-colors"
          >
            💕 "كل لحظة معكِ هي جنة"
          </button>
        </div>
      </div>
    </div>
  )
}