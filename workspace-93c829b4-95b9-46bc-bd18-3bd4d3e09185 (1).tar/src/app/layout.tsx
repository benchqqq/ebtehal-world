import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/components/auth-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "عالم ابتهال - مساحة حب خاصة",
  description: "المكان الذي يلتقي فيه القلبان، عالم رومانسي خاص بحبيبتي ابتهال",
  keywords: ["حب", "رومانسية", "ابتهال", "عشاق", "مساحة خاصة"],
  authors: [{ name: "حبيب ابتهال" }],
  openGraph: {
    title: "عالم ابتهال 💕",
    description: "المكان الذي يلتقي فيه القلبان",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
