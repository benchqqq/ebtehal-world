import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST(request: NextRequest) {
  try {
    const { name, password } = await request.json()

    if (!name || !password) {
      return NextResponse.json(
        { error: 'الاسم وكلمة السر مطلوبان' },
        { status: 400 }
      )
    }

    // البحث عن الزوجين
    const couple = await db.couple.findFirst({
      where: {
        OR: [
          { name1: name },
          { name2: name }
        ]
      }
    })

    if (!couple) {
      return NextResponse.json(
        { error: 'هذا الاسم غير مسجل في عالمنا السري' },
        { status: 401 }
      )
    }

    // التحقق من كلمة السر
    const isValidPassword = await bcrypt.compare(password, couple.password)

    if (!isValidPassword) {
      return NextResponse.json(
        { error: 'كلمة السر غير صحيحة' },
        { status: 401 }
      )
    }

    // إنشاء جلسة بسيطة (في تطبيق حقيقي، استخدم JWT)
    const response = NextResponse.json({
      success: true,
      coupleId: couple.id,
      user1Name: couple.name1,
      user2Name: couple.name2,
      currentUserName: name
    })

    // تعيين الكوكيز
    response.cookies.set('coupleId', couple.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 30 // 30 days
    })

    response.cookies.set('currentUserName', name, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 30 // 30 days
    })

    return response

  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما، حاول مرة أخرى' },
      { status: 500 }
    )
  }
}