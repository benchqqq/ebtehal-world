import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value

    if (!coupleId) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const scores = await db.gameScore.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(scores)

  } catch (error) {
    console.error('Get game scores error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const coupleId = request.cookies.get('coupleId')?.value
    const currentUserName = request.cookies.get('currentUserName')?.value

    if (!coupleId || !currentUserName) {
      return NextResponse.json(
        { error: 'غير مصرح لك' },
        { status: 401 }
      )
    }

    const { gameName, score } = await request.json()

    if (!gameName || score === undefined) {
      return NextResponse.json(
        { error: 'اسم اللعبة والنتيجة مطلوبان' },
        { status: 400 }
      )
    }

    const gameScore = await db.gameScore.create({
      data: {
        gameName,
        score,
        player: currentUserName,
        coupleId
      }
    })

    return NextResponse.json(gameScore)

  } catch (error) {
    console.error('Create game score error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ ما' },
      { status: 500 }
    )
  }
}